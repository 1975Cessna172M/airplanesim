public interface Fly {
    void takeOff();
    void land();
}
// interface to show what implementing objects SHOULD be able to do
